<?php
require('database.php');
$submit = filter_input(INPUT_POST, 'submit');
$num1 = filter_input(INPUT_POST, 'num1');
$num2 = filter_input(INPUT_POST, 'num2');
 //Adding numbers
    function addition($num1, $num2) {
        $add = $num1 + $num2;
        return $add;
    }
    function subtraction($num1, $num2) {
        $subtract = $num1 - $num2;
        return $subtract;
    }
    function multiplication($num1, $num2) {
        $multiply = $num1 * $num2;
        return $multiply;
    }
    function division($num1, $num2) {
        $divide = $num1 / $num2;
        return $divide;
    }
?>


<!DOCTYPE html>
<html>
    <head>
        <title>
            Calculator
        </title>
    </head>
    <body>
        <h1>Calculator</h1>
        <form action="calculator.php" method="post">
        <label>Number 1 </label>
        <input type="text" name="num1">
        <br>
        <label>Number 2 </label>
        <input type="text" name="num2">
        <br>
        <input type="submit" name="submit" value="submit">
        </form>
        
        <h1>Calculations</h1>
        <table>
             <?php 
             if ($submit == 'submit') {
                 echo "<tr>";
                 echo "<th>";
                 echo "Num1";
                 echo "</th>";
                 echo "<th>";
                 echo "Num2";
                 echo "</th>";
                 echo "<th>";
                 echo "Addition";
                 echo "</th>";
                 echo "<th>";
                 echo "Subtraction";
                 echo "</th>";
                 echo "<th>";
                 echo "Multiply";
                 echo "</th>";
                 echo "<th>";
                 echo "Divide";
                 echo "</th>";
                 echo "</tr>";
                 echo "<tr>";
                 echo "<td>";
                 echo ($_POST['num1']);
                 echo "</td>";
                 echo "<td>";
                 echo ($_POST['num2']);
                 echo "</td>";
                 echo "<td>";
                 echo addition($num1, $num2);
                 echo "</td>";
                 echo "<td>";
                 echo subtraction($num1, $num2);
                 echo "</td>";
                 echo "<td>";
                 echo multiplication($num1, $num2);
                 echo "</td>";
                 echo "<td>";
                 echo division($num1, $num2);
                 echo "</td>";
                 echo "</tr>";
             }
             ?>
        </table>
        
      
    </body>
</html>