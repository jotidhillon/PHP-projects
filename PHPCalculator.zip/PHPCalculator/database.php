<?php
    if (isset($db)) {
        $db = db_connect();
    }
    
    if (!isset($message)) {
        $message = "";
    }
    
    function db_connect() {
        try {
            $dsn = 'mysql:host=localhost;dbname=review';
            $username = 'labuser';
            $password = 'dc123';
            $db = new PDO($dsn, $username, $password);
            return $db;
        }
        catch (PDOException $e) {
            $message = $e->getMessage();
            include('database_error.php');
            exit();
        }
    }
    //Inserting Numbers into table
    function numinsert($num1, $num2) {
        global $db;
        $query = 'INSERT INTO numbers (num1, num2)
                  VALUES (:num1, :num2)';
        $statement = $db->prepare($query);
        $statement->bindValue(':num1', $num1);
        $statement->bindValue(':num2', $num2);
        $numbers = $statement->execute();
        $statement->closeCursor();
        return $numbers;
    }
    //Selecting Numbers for table
    function numselect($num1, $num2) {
        global $db;
        $query = 'SELECT * FROM numbers
                  ORDER BY id';
        $statement = $db->prepare($query);
          $statement->bindValue(':num1', $num1);
        $statement->bindValue(':num2', $num2);
        $numberselect = $statement->execute();
        $statement->closeCursor();
        return $numberselect;
        
    }
   
 ?>